package cn.tju.scs;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class testCaculator {
	private Caculator cal;
	@Before
	public void setUp(){
		cal = new Caculator();
	}
	@Test
	public void testEquilateral(){
		assertEquals(false,cal.isTriangle(0,1,2));
		assertEquals(false,cal.isTriangle(-3,-4,-5));
		
		assertEquals(true,cal.isTriangle(2,3,4));
		assertEquals(false,cal.isTriangle(1,8,9));
		assertEquals(false,cal.isTriangle(1,3,5));
		
		assertEquals(true,cal.equilateral(2,2,2));
		assertEquals(false,cal.equilateral(2,3,2));
		assertEquals(false,cal.equilateral(3,4,5));
		
		assertEquals(false,cal.isosceles(3,3,3));
		assertEquals(true,cal.isosceles(2,3,2));
		assertEquals(false,cal.isosceles(2,3,4));
		
		assertEquals(false,cal.scalene(3,3,3));
		assertEquals(false,cal.scalene(2,3,2));
		assertEquals(true,cal.scalene(3,4,5));

	}
}

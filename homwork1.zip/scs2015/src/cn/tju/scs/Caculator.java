package cn.tju.scs;

public class Caculator {
	public boolean isTriangle(int a,int b,int c){
		if(a<=0||b<=0||c<=0) return false;
		if(a+b>c&&a+c>b&&b+c>a) return true;
		return false;
	}
	public boolean equilateral(int a,int b,int c){
		if(!isTriangle(a,b,c)) return false;
		if(a==b&&b==c) return true;
		return false;
	}
	public boolean isosceles(int a,int b,int c){
		if(!isTriangle(a,b,c)) return false;
		if(a==b&&a!=c) return true;
		if(a==c&&a!=b) return true;
		if(b==c&&b!=a) return true;
		return false;
	}
	public boolean scalene(int a,int b,int c){
		if(!isTriangle(a,b,c)) return false;
		if(a!=b&&b!=c&&a!=c) return true;
		return false;
	}
}
